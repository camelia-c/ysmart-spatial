package ANTLR::Runtime::EarlyExitException;

use strict;
use warnings;

use base qw( ANTLR::Runtime::Exception );

1;
